package ca.sheridancollege.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import ca.sheridancollege.beans.Players;

public interface PlayerRepository extends CrudRepository<Players, Integer> {

Players findById(int id);
	
	
	long count();
	List<Players> findByName(String name);
	List<Players> findByAge(int age);
	List<Players> findByPhonenumber(String phonenumber);
	List<Players> findByGender(char gender);
	List<Players> findByEmail(String email);
	
}
