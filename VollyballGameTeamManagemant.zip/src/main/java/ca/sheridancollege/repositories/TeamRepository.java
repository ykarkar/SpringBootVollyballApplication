package ca.sheridancollege.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import ca.sheridancollege.beans.Players;
import ca.sheridancollege.beans.Team1;

public interface TeamRepository extends CrudRepository<Team1, Integer> {

		Team1 findById(int id);
		
		
}
