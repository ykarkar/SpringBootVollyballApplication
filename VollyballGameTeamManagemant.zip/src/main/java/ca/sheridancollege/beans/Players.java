package ca.sheridancollege.beans;


import java.util.List;

import javax.persistence.*;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity

@Embeddable
public class Players {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String name;
	private int age;
	private char gender;
	private String  phonenumber;
	private String email;

	@Transient
	private char[] genders = {'M', 'F'};
	
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER ,
			mappedBy = "players")
	private List<Team1> team;
	
//	@OneToOne(cascade = CascadeType.ALL)	
//	private List<Team> team;
}
