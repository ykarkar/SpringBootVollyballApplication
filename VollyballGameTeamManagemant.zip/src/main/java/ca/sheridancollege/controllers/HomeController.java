package ca.sheridancollege.controllers;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.sheridancollege.beans.Players;

import ca.sheridancollege.beans.Team1;
import ca.sheridancollege.repositories.PlayerRepository;
import ca.sheridancollege.repositories.TeamRepository;


@Controller
public class HomeController {
	
	
	
	@Autowired
	private PlayerRepository prepository;
	

	@Autowired
	private TeamRepository trepository;
	
	
	
	
	
	@GetMapping("/")
	public String gohome(){
		return "home.html";
	}
	
	
	
	@GetMapping("/generateprofile")
	public String generateProfile(Model model) {
		 int total = (int) prepository.count();

		if(total > 34) {
			 return "Error.html";

		 }
		 else {
		String alphabets="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		 String gen="MF";
		 
		//This code generates 30 random profiles.
		 int numofplayer = 0;
		 
		while(numofplayer != 30 ) {
			String name ="";
			int length = 6;
			Random rand = new Random();		
			char[] text = new char[length];
		for(int i=0; i<length;i++) {
			 text[i] = alphabets.charAt(rand.nextInt(alphabets.length()));
		 }
		 
		 for(int i=0; i<text.length;i++) {
			 name += text[i];
		 }
		 
		 //Generate if player is male or female
		 char gender; 
			gender = gen.charAt(rand.nextInt(gen.length()));
		
			//generates mobile number of the player
		int num1 = rand.nextInt(888) + 111;
		int num2 = rand.nextInt(888) + 111;
		int num3 = rand.nextInt(1111) + 111;
		String phonenumber = Integer.toString(num1) + Integer.toString(num2)+Integer.toString(num3);
		
			
		 //generates age of the player
			int age = rand.nextInt(71) + 10;
			
	
			//generates an email
			String email = name + "." + gender +"@" + "gmail.com" ;
			
		Players p = Players.builder().name(name).age(age).gender(gender).phonenumber(phonenumber).email(email).build(); 

		//prepository.save(p);
		numofplayer++;
		
		Players con = prepository.save(p);
		//vgRepository.save(videogame);
	
			//model.addAttribute("mycontacts", prepository.findAll()); //this is the variable from which we are getting the data to the next page.
		//model.addAttribute("contacts", new Players());
		}
		System.out.println(total);
		
		
		model.addAttribute("myplayers", prepository.findAll());
		return "ViewPlayer.html";
		 }
	}
	@GetMapping("/ViewTeam")
	public String viewteam() {
		return "ViewTeams.html";
	}
	@GetMapping("/organizePlayer")
	public String organizePlayer(Model model) {
		model.addAttribute("players", new Players());
		System.out.println("PlayersOrganized");
		
		
//		int MAX_Player = 64;
//		int MIN_Player = 20;
//		List<Players> Male = prepository.findByGender('M');
//		for(int i = 0; i < Male.size(); i++) {
//            System.out.println(Male.get(i).getName() +  Male.get(i).getGender());
//        }
//		List<Players> Female = prepository.findByGender('F');
//		
//		 int teamnum = 0;
//		 int minplayer =0;
//		 
//		
//	//	System.out.println("Total Players " + total);
//		 int total = (int) prepository.count();
//		 if(total <= 35) {
//			 teamnum = 6;
//			 minplayer = 35/6;
//		 }
//		 else if(total >= 35 && total < 40) {
//			 teamnum = 7;
//			 minplayer = 40/7;
//		 }
//		 else if(total >= 40) {
//			 teamnum = 8;
//			 minplayer = 64/8;
//		 }
//			 
//		 int k=0;
//		 
//			// for(int i=0;i<teamnum;i++) {
//				// for(int j=0; j<maxplayer;j++) {
//					 
////					 Team1 c = trepository.findById(1);
////						Players s = prepository.findById(1);
////						Players s2 = prepository.findById(2);
////						c.getPlayers().add(s);
////						c.getPlayers().add(s2);
////						s.getTeam().add(c);
////						trepository.save(c);
////						
////						System.out.println(" Team Num "+teamnum + "  and  Total Player" + total + "Min Player " + minplayer );
//		
						return "redirect:/";
	}
	
	@GetMapping("/GoToMovePlayerToTheTeam")
	public String GoToMovePlayerToTheTeam(Model model) {
		//model.addAttribute("players",prepository.findAll());
		
		model.addAttribute("teams",trepository.findAll());
	
		
		return "MoveSwapPlayers.html";
	}
	
	@GetMapping("/searchPlayerFromTeam")
	public String searchPlayerFromTeam(@RequestParam int teamid ,Model model) {
		//model.addAttribute("players",prepository.findAll());
//		Team t = trepository.findById(teamid);

	//	model.addAttribute("teamPlayer",t);
		 Team1 c = trepository.findById(teamid);
			List<Players> p =  c.getPlayers();
		System.out.println(p);
		return "MoveSwapPlayers.html";
	}
	
	@GetMapping("/saveTeamSelect")
	public String saveTeamSelect() {
		
		
		return "ViewTeams.html";
	}
	@GetMapping("/GoToAddPlayer")
	public String GoToAddPlayer(Model model) {
		model.addAttribute("players", new Players());
		return "AddPlayer.html";
	}
	@GetMapping("/GoToSearchPlayer")
	public String GoToSearchPlayer(Model model) {
		model.addAttribute("players", new Players());
		return "SearchPlayer.html";
	}
	@GetMapping("/searchByName")
	public String searchbyname(@RequestParam String name,
			Model model) {
		
		List<Players> conn = prepository.findByName(name);
		model.addAttribute("myplayers", conn);
		return "SearchPlayer.html";	
	}
	
	@GetMapping("/searchByNamefromview")
	public String searchbynamefromview(@RequestParam String name,
			Model model) {
		
		List<Players> conn = prepository.findByName(name);
		model.addAttribute("myplayers", conn);
		return "ViewPlayer.html";	
	}
	@GetMapping("/searchByAgefromview")
	public String searchbyagefromview(@RequestParam int age,
			Model model) {
		
		List<Players> conn = prepository.findByAge(age);
		model.addAttribute("myplayers", conn);
		return "ViewPlayer.html";	
	}
	
	@GetMapping("/searchByGenderfromview")
	public String searchbygenderfromview(@RequestParam char gender,
			Model model) {
		
		List<Players> conn = prepository.findByGender(gender);
		model.addAttribute("myplayers", conn);
		return "ViewPlayer.html";	
	}
	
	
	@GetMapping("/searchByAge")
	public String searchbyage(@RequestParam int age,
			Model model) {
		
		List<Players> conn = prepository.findByAge(age);
		model.addAttribute("myplayers", conn);
		return "SearchPlayer.html";	
	}
	
	@GetMapping("/searchByGender")
	public String searchbygender(@RequestParam char gender,
			Model model) {
		
		List<Players> conn = prepository.findByGender(gender);
		model.addAttribute("myplayers", conn);
		return "SearchPlayer.html";	
	}
	
	@GetMapping("/searchByTeam")
	public String searchbyteam(@RequestParam String team,
			Model model) {
		
		List<Players> conn = prepository.findByName(team);
		model.addAttribute("myplayers", conn);
		return "SearchPlayer.html";	
	}
	
	
	
	@GetMapping("/addPlayers")
	public String addPlayer(@ModelAttribute Players player,
							Model model) {
		 int total = (int) prepository.count();

			if(total > 34) {
				 return "Error.html";

			 }
			else {
	prepository.save(player);
		model.addAttribute("myplayers", prepository.findAll());
		model.addAttribute("players", new Players());
		return "ViewPlayer.html";
			}
	}
		
	
	
	@GetMapping("/GoToViewPlayer")
	public String GoToViewPlayer(@ModelAttribute Players p, 
			Model model) {

		//Players con = prepository.save(p);
		model.addAttribute("myplayers", prepository.findAll()); //this is the variable from which we are getting the data to the next page.
		//model.addAttribute("players", new Players());
		
		return "ViewPlayer.html";
	}
	
	
	@GetMapping("/editlink/{id}")
	public String edit( @PathVariable int id, Model model){
	if (prepository.findById(id) != null) {
	Players play = prepository.findById(id);
	model.addAttribute("players", play);
	return "EditPlayer.html";
	}else {
	return "redirect:/";
	}
	
	}
	
	@GetMapping("/deletelink/{id}")
	public String delete(@ModelAttribute Players p,@PathVariable int id, Model model){
	if (prepository.findById(id) != null) {
      prepository.deleteById(id);
 	 //Players play = prepository.findById(id);
      //model.addAttribute("contact", play);
      
     // Players con = prepository.save(p);
		model.addAttribute("myplayers", prepository.findAll()); //this is the variable from which we are getting the data to the next page.
	//	model.addAttribute("players", new Players());

	return "ViewPlayer.html";
	}else {
	return "redirect:/";
	}

	
	}
	@GetMapping("/modify")
	public String modify(@ModelAttribute Players p,
			Model model) {
		prepository.save(p);
		
		Players con = prepository.save(p);
		model.addAttribute("myplayers", prepository.findAll()); //this is the variable from which we are getting the data to the next page.
		model.addAttribute("players", new Players());

	return "ViewPlayer.html";
	}
	

	
	
}
