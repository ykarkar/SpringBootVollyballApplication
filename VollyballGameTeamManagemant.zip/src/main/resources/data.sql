INSERT INTO Players (name, age, gender, phonenumber, email) 
		VALUES ('Yash', 19, 'M', '3652283786', 'yashkarkar.yk@gmailcom');
INSERT INTO Players (name, age, gender, phonenumber, email) 
		VALUES ('Kashyap', 18, 'M', '3652283486', 'kashyap.yk@gmailcom');
INSERT INTO Players (name, age, gender, phonenumber, email) 
		VALUES ('Dhruv', 12, 'M', '6472234436', 'dhruv.yk@gmailcom');